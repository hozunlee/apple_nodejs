const chat = (params) => {
    console.log("Hello");
};

chat();

console.log("메세지");

/**
 *
 * @param {number} a 1번째 더할 숫자
 * @param {number} b 2번째 더할 숫자
 * @returns 이거 두개를 더 한 값
 */

function sum(a, b) {
    return a + b;
}

sum(3, 4);
